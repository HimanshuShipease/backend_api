from rest_framework import serializers
from django.db import models
from weightreco_app.models import WeightReconciliation,WeightReconciliationHistory
# from billing_app.models import Transactions,CodTransactions,Invoice,BillReceipt


class WeightReconciliationSerializer(serializers.ModelSerializer):
    class Meta:
        model = WeightReconciliation
        fields = '__all__'
