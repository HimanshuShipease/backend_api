from django.shortcuts import render



from weightreco_app.models import WeightReconciliation
from weightreco_app.serializers import WeightReconciliationSerializer
from django.http import Http404
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.utils import timezone
from datetime import datetime, timedelta

global_seller_id=14366

class WeightReconciliationList(APIView):
    def get(self, request, format=None):
        one_month_ago = datetime.now() - timedelta(days=30)
        snippets = WeightReconciliation.objects.all()[:30]
        serializer = WeightReconciliationSerializer(snippets, many=True)
        return Response(serializer.data)